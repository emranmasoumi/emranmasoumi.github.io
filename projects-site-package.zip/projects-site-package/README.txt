PROJECTS PAGE PACKAGE

Files included:
- src/pages/projects.astro
- src/pages/projects/[slug].astro
- public/images/projects/ (4 project images)
- PROJECTS-CSS.txt
- HOMEPAGE-PROJECTS-BLOCK.txt

Installation:
1. Copy the `projects.astro` file into src/pages/.
2. Create src/pages/projects/ and copy [slug].astro there.
3. Create public/images/projects/ and copy the four JPG files there.
4. Append PROJECTS-CSS.txt to src/styles/global.css.
5. Update the homepage project data and link using HOMEPAGE-PROJECTS-BLOCK.txt.
6. Run: npm run build
7. If successful: git add . && git commit -m "Build project portfolio and case studies" && git push

Routes created:
/projects
/projects/ai-product-recommendation
/projects/customer-segmentation
/projects/rag-document-assistant
/projects/arofrag
